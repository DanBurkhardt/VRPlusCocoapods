//
//  VRPlus.h
//  VRPlus
//
//  Created by Daniel Burkhardt on 3/10/17.
//  Copyright © 2017 Giganom LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VRPlus.
FOUNDATION_EXPORT double VRPlusVersionNumber;

//! Project version string for VRPlus.
FOUNDATION_EXPORT const unsigned char VRPlusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VRPlus/PublicHeader.h>


